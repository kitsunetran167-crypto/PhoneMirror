package com.example.phonemirror

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.net.Inet4Address
import java.net.NetworkInterface

class MainActivity : Activity() {

    private val reqProjection = 100
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        status = TextView(this).apply { textSize = 16f }

        val btnAccess = Button(this).apply {
            text = "1. Bật quyền chạm (Trợ năng)"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        val btnStart = Button(this).apply {
            text = "2. Bắt đầu chiếu lên ESP32"
            setOnClickListener {
                val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                @Suppress("DEPRECATION")
                startActivityForResult(mpm.createScreenCaptureIntent(), reqProjection)
            }
        }
        val btnStop = Button(this).apply {
            text = "Dừng"
            setOnClickListener {
                stopService(Intent(this@MainActivity, MirrorService::class.java))
                refresh()
            }
        }

        root.addView(status)
        root.addView(btnAccess)
        root.addView(btnStart)
        root.addView(btnStop)
        setContentView(root)

        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val ip = localIp() ?: "chưa kết nối WiFi"
        val touch = if (TouchService.instance != null) "ĐÃ BẬT" else "CHƯA BẬT"
        val mirror = if (MirrorService.running) "ĐANG CHIẾU" else "ĐANG DỪNG"
        status.text = "IP điện thoại: $ip\nCổng: ${MirrorService.PORT}\n" +
            "Quyền chạm: $touch\nChiếu màn hình: $mirror\n\n" +
            "Điền IP trên vào PC_IP trong code ESP32."
    }

    private fun localIp(): String? {
        for (ni in NetworkInterface.getNetworkInterfaces()) {
            if (ni.name != "wlan0" && !ni.name.startsWith("ap")) continue
            for (addr in ni.inetAddresses) {
                if (addr is Inet4Address && !addr.isLoopbackAddress) return addr.hostAddress
            }
        }
        return null
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqProjection && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, MirrorService::class.java)
                .putExtra(MirrorService.EXTRA_CODE, resultCode)
                .putExtra(MirrorService.EXTRA_DATA, data)
            startForegroundService(i)
            status.postDelayed({ refresh() }, 800)
        }
    }
}
