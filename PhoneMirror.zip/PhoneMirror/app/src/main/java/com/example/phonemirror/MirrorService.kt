package com.example.phonemirror

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.view.WindowManager
import java.io.InputStream
import java.net.ServerSocket
import java.net.Socket
import kotlin.concurrent.thread
import kotlin.math.abs

/**
 * Chụp màn hình điện thoại (MediaProjection), thu nhỏ về 240x320 RGB565 và gửi
 * cho ESP32 qua TCP. Nhận lại tọa độ chạm từ ESP32 để điều khiển điện thoại.
 */
class MirrorService : Service() {

    companion object {
        const val W = 240
        const val H = 320
        const val PORT = 5000
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        @Volatile
        var running = false
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var captureThread: HandlerThread? = null
    private var server: ServerSocket? = null

    @Volatile
    private var latest: ByteArray? = null
    private var screenW = 1080
    private var screenH = 2400

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || running) return START_NOT_STICKY

        startForegroundNotification()

        val code = intent.getIntExtra(EXTRA_CODE, 0)
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>(EXTRA_DATA) ?: return START_NOT_STICKY

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }, null)

        val bounds = (getSystemService(Context.WINDOW_SERVICE) as WindowManager)
            .maximumWindowMetrics.bounds
        screenW = bounds.width()
        screenH = bounds.height()

        startCapture()
        startServer()
        running = true
        return START_NOT_STICKY
    }

    private fun startForegroundNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("mirror", "PhoneMirror", NotificationManager.IMPORTANCE_LOW)
        )
        val notif = Notification.Builder(this, "mirror")
            .setContentTitle("PhoneMirror đang chiếu lên ESP32")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    private fun startCapture() {
        val ht = HandlerThread("capture").also { it.start() }
        captureThread = ht
        val handler = Handler(ht.looper)

        val r = ImageReader.newInstance(W, H, PixelFormat.RGBA_8888, 2)
        reader = r
        r.setOnImageAvailableListener({ ir ->
            val img = ir.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val plane = img.planes[0]
                val buf = plane.buffer
                val rowStride = plane.rowStride
                val pixelStride = plane.pixelStride
                val out = ByteArray(W * H * 2)
                var o = 0
                for (y in 0 until H) {
                    var p = y * rowStride
                    for (x in 0 until W) {
                        val rr = buf.get(p).toInt() and 0xFF
                        val gg = buf.get(p + 1).toInt() and 0xFF
                        val bb = buf.get(p + 2).toInt() and 0xFF
                        val v = ((rr and 0xF8) shl 8) or ((gg and 0xFC) shl 3) or (bb shr 3)
                        out[o++] = (v and 0xFF).toByte()        // little-endian
                        out[o++] = ((v shr 8) and 0xFF).toByte()
                        p += pixelStride
                    }
                }
                latest = out
            } finally {
                img.close()
            }
        }, handler)

        val dpi = resources.displayMetrics.densityDpi
        display = projection?.createVirtualDisplay(
            "PhoneMirror", W, H, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            r.surface, null, handler
        )
    }

    private fun startServer() {
        thread(name = "server") {
            try {
                val ss = ServerSocket(PORT)
                server = ss
                while (!ss.isClosed) {
                    val client = ss.accept()
                    client.tcpNoDelay = true
                    handleClient(client)
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun handleClient(client: Socket) {
        val reader = thread(name = "touch-in") { readTouch(client.getInputStream()) }
        try {
            val out = client.getOutputStream()
            while (!client.isClosed && running) {
                val frame = latest
                if (frame != null) {
                    out.write(frame)
                    out.flush()
                }
                Thread.sleep(70)
            }
        } catch (_: Exception) {
        } finally {
            try { client.close() } catch (_: Exception) {}
            reader.interrupt()
        }
    }

    private fun readTouch(input: InputStream) {
        val pkt = ByteArray(5)
        var downX = 0
        var downY = 0
        var isDown = false
        try {
            while (true) {
                var n = 0
                while (n < 5) {
                    val k = input.read(pkt, n, 5 - n)
                    if (k < 0) return
                    n += k
                }
                val kind = pkt[0].toInt().toChar()
                val x = (pkt[1].toInt() and 0xFF) or ((pkt[2].toInt() and 0xFF) shl 8)
                val y = (pkt[3].toInt() and 0xFF) or ((pkt[4].toInt() and 0xFF) shl 8)
                val px = x * screenW.toFloat() / W
                val py = y * screenH.toFloat() / H
                if (kind == 'D') {
                    downX = x; downY = y; isDown = true
                } else if (kind == 'U' && isDown) {
                    isDown = false
                    val svc = TouchService.instance ?: continue
                    val sx = downX * screenW.toFloat() / W
                    val sy = downY * screenH.toFloat() / H
                    if (abs(px - sx) < 30 && abs(py - sy) < 30) {
                        svc.tap(px, py)
                    } else {
                        svc.swipe(sx, sy, px, py, 250)
                    }
                }
            }
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        running = false
        try { server?.close() } catch (_: Exception) {}
        display?.release()
        reader?.close()
        projection?.stop()
        captureThread?.quitSafely()
        super.onDestroy()
    }
}
